#COMP249 Web Application Assignment 2018

###Starter Pack

This repository contains the starter code for the 
2018 web application assignment for COMP249.  You can download
this code as a zip file via the downloads link (on the left) or
you can fork this repository if you want to track your work
with Git.  

A demonstration version of the application is running at 
http://comp249.stevecassidy.net/ 

